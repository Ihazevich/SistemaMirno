﻿using SistemaMirno.Model;

namespace SistemaMirno.UI.Data.Repositories.Interfaces
{
    public interface IBranchRepository : IGenericRepository<Branch>
    {
    }
}