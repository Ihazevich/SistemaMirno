﻿using Prism.Events;

namespace SistemaMirno.UI.Event
{
    public class ShowDialogEvent : PubSubEvent<ShowDialogEventArgs>
    {
    }
}
