﻿using System.Threading.Tasks;

namespace SistemaMirno.UI.ViewModel.Detail.Interfaces
{
    public interface IUserDetailViewModel : IDetailViewModelBase
    {
    }
}