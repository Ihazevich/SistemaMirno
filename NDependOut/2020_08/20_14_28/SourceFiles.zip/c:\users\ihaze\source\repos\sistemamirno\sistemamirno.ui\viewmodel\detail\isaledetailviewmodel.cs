﻿using System.Threading.Tasks;

namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface ISaleDetailViewModel : IDetailViewModelBase
    {
    }
}