﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IMaterialDetailViewModel : IDetailViewModelBase
    {
    }
}