﻿namespace SistemaMirno.UI.Event
{
    public struct BranchChangedEventArgs
    {
        public int BranchId { get; set; }

        public string Name { get; set; }
    }
}