﻿// <copyright file="AfterDataModelSavedEvent.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using Prism.Events;
using SistemaMirno.Model;

namespace SistemaMirno.UI.Event
{
    public class ReloadNavigationViewEvent : PubSubEvent
    {
    }
}
