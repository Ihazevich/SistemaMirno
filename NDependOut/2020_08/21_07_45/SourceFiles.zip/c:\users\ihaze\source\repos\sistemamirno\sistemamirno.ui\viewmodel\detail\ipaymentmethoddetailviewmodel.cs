﻿// <copyright file="PaymentMethodDetailViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Threading.Tasks;

namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IPaymentMethodDetailViewModel : IDetailViewModelBase
    {
    }
}