﻿using System.Windows.Controls;

namespace SistemaMirno.UI.View
{
    /// <summary>
    /// Interaction logic for AreaConnectionView.xaml
    /// </summary>
    public partial class AreaConnectionView : UserControl
    {
        public AreaConnectionView()
        {
            InitializeComponent();
        }
    }
}
