﻿// <copyright file="ClientDetailViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IClientDetailViewModel : IDetailViewModelBase
    {
    }
}