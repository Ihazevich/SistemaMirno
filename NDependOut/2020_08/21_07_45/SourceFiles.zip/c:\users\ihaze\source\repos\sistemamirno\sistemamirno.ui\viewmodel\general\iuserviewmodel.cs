﻿// <copyright file="UserViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Threading.Tasks;

namespace SistemaMirno.UI.ViewModel.General
{
    public interface IUserViewModel : IViewModelBase
    {
    }
}