﻿// <copyright file="LoginViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Threading.Tasks;

namespace SistemaMirno.UI.ViewModel.Main
{
    public interface ILoginViewModel : IViewModelBase
    {
    }
}