﻿// <copyright file="BranchView.xaml.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Windows.Controls;

namespace SistemaMirno.UI.View.General
{
    /// <summary>
    /// Interaction logic for BranchView.xaml.
    /// </summary>
    public partial class BranchView : UserControl
    {
        public BranchView()
        {
            InitializeComponent();
        }
    }
}
