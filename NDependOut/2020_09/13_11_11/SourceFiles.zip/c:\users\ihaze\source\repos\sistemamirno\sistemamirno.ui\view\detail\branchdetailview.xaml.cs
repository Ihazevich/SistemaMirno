﻿// <copyright file="BranchDetailView.xaml.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Windows.Controls;

namespace SistemaMirno.UI.View.Detail
{
    /// <summary>
    /// Interaction logic for BranchDetailView.xaml
    /// </summary>
    public partial class BranchDetailView : UserControl
    {
        public BranchDetailView()
        {
            InitializeComponent();
        }
    }
}
