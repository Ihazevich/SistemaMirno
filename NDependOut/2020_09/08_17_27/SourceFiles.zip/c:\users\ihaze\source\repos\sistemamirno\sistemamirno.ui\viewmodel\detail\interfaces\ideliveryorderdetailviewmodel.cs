﻿using SistemaMirno.UI.ViewModel.Detail.Interfaces;

namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IDeliveryOrderDetailViewModel : IDetailViewModelBase
    {
    }
}