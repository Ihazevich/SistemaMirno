﻿// <copyright file="RoleDetailView.xaml.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Windows.Controls;

namespace SistemaMirno.UI.View.Detail
{
    /// <summary>
    /// Interaction logic for RoleDetailView.xaml.
    /// </summary>
    public partial class RoleDetailView : UserControl
    {
        public RoleDetailView()
        {
            InitializeComponent();
        }
    }
}
