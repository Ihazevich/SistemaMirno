﻿// <copyright file="NotifyStatusBarEvent.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using Prism.Events;

namespace SistemaMirno.UI.Event
{
    public class NotifyStatusBarEvent : PubSubEvent<NotifyStatusBarEventArgs>
    {
    }
}
