﻿using SistemaMirno.Model;

namespace SistemaMirno.UI.Data.Repositories
{
    public interface IBranchRepository :  IGenericRepository<Branch>
    {
    }
}