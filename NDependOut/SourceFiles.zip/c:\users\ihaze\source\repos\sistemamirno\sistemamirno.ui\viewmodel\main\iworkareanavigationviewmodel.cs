﻿namespace SistemaMirno.UI.ViewModel.Main
{
    public interface IWorkAreaNavigationViewModel : IViewModelBase
    {
    }
}