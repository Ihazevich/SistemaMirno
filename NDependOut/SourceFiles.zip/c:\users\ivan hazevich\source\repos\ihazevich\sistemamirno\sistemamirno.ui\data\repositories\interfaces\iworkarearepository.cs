﻿using System.Collections.Generic;
using System.Threading.Tasks;
using SistemaMirno.Model;
using SistemaMirno.UI.Data.Repositories.Interfaces;

namespace SistemaMirno.UI.Data.Repositories.Interfaces
{
    public interface IWorkAreaRepository : IGenericRepository<WorkArea>
    {
        Task<List<WorkArea>> GetAllWorkAreasFromBranch(int id);
        Task<bool> CheckIfLastExists();
        Task<bool> CheckIfFirstExists();
    }
}