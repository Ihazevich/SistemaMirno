﻿// <copyright file="ProductionByEmployeeView.xaml.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

using System.Windows.Controls;

namespace SistemaMirno.UI.View.Reports
{
    /// <summary>
    /// Interaction logic for ProductionByEmployeeView.xaml
    /// </summary>
    public partial class ProductionByEmployeeView : UserControl
    {
        public ProductionByEmployeeView()
        {
            InitializeComponent();
        }
    }
}
