﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Events;
using SistemaMirno.UI.ViewModel.Detail;

namespace SistemaMirno.UI.Event
{
    public class CloseDetailViewEvent<T> : PubSubEvent
        where T : IDetailViewModelBase
    {
    }
}
