﻿using System.Windows.Controls;

namespace SistemaMirno.UI.View
{
    /// <summary>
    /// Interaction logic for AreaConnectionDetailView.xaml
    /// </summary>
    public partial class AreaConnectionDetailView : UserControl
    {
        public AreaConnectionDetailView()
        {
            InitializeComponent();
        }
    }
}
