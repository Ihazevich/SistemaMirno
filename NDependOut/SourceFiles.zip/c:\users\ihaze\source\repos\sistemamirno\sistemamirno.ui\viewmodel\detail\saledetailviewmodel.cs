﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using MahApps.Metro.Controls.Dialogs;
using Prism.Commands;
using Prism.Events;
using SistemaMirno.Model;
using SistemaMirno.UI.Data.Repositories.Interfaces;
using SistemaMirno.UI.Event;
using SistemaMirno.UI.ViewModel.General;
using SistemaMirno.UI.Wrapper;

namespace SistemaMirno.UI.ViewModel.Detail
{
    public class SaleDetailViewModel : DetailViewModelBase
    {
        private ISaleRepository _saleRepository;
        private SaleWrapper _sale;
        private WorkUnit _selectedSaleWorkUnit;
        private WorkUnit _selectedExistingWorkUnit;

        private readonly PropertyGroupDescription _description = new PropertyGroupDescription("Description");

        public SaleDetailViewModel(
            ISaleRepository saleRepository,
            IEventAggregator eventAggregator,
            IDialogCoordinator dialogCoordinator)
            : base(eventAggregator, "Detalles de Venta", dialogCoordinator)
        {
            _saleRepository = saleRepository;

            Branches = new ObservableCollection<Branch>();
            Clients = new ObservableCollection<Client>();
            Responsibles = new ObservableCollection<Employee>();
            ExistingWorkUnits = new ObservableCollection<WorkUnit>();
            SaleWorkUnits = new ObservableCollection<WorkUnit>();

            ExistingWorkUnitsCollectionView = CollectionViewSource.GetDefaultView(ExistingWorkUnits);
            SaleWorkUnitsCollectionView = CollectionViewSource.GetDefaultView(SaleWorkUnits);
        }

        public ICollectionView ExistingWorkUnitsCollectionView { get; }

        public ICollectionView SaleWorkUnitsCollectionView { get; }

        public ObservableCollection<Branch> Branches { get; }

        public ObservableCollection<Client> Clients { get; }

        public ObservableCollection<Employee> Responsibles { get; }

        public ObservableCollection<WorkUnit> ExistingWorkUnits { get; }

        public ObservableCollection<WorkUnit> SaleWorkUnits { get; }

        public SaleWrapper Sale
        {
            get => _sale;

            set
            {
                _sale = value;
                OnPropertyChanged();
            }
        }

        /// <inheritdoc/>
        public override async Task LoadDetailAsync(int id)
        {
            var model = await _saleRepository.GetByIdAsync(id);

            Application.Current.Dispatcher.Invoke(() =>
            {
                Sale = new SaleWrapper(model);
                Sale.PropertyChanged += Model_PropertyChanged;
                ((DelegateCommand)SaveCommand).RaiseCanExecuteChanged();
            });

            await base.LoadDetailAsync(id).ConfigureAwait(false);
        }

        /// <inheritdoc/>
        protected override async void OnSaveExecute()
        {
            base.OnSaveExecute();

            if (IsNew)
            {
                await _saleRepository.AddAsync(Sale.Model);
            }
            else
            {
                await _saleRepository.SaveAsync(Sale.Model);
            }

            HasChanges = false;
            EventAggregator.GetEvent<ChangeNavigationStatusEvent>()
                .Publish(true);
        }

        /// <inheritdoc/>
        protected override bool OnSaveCanExecute()
        {
            return OnSaveCanExecute(Sale);
        }

        protected override void OnCancelExecute()
        {
            base.OnCancelExecute();
            EventAggregator.GetEvent<ChangeNavigationStatusEvent>()
                .Publish(true);
        }

        private void Model_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (!HasChanges)
            {
                HasChanges = _saleRepository.HasChanges();
            }

            if (e.PropertyName == nameof(Sale.HasErrors))
            {
                ((DelegateCommand)SaveCommand).RaiseCanExecuteChanged();
            }
        }

        public override async Task LoadAsync(int? id = null)
        {
            await LoadBranchesAsync();
            await LoadClientsAsync();
            await LoadResponsiblesAsync();

            if (id.HasValue)
            {
                await LoadDetailAsync(id.Value);
                return;
            }

            await LoadWorkUnitAsync();

            Application.Current.Dispatcher.Invoke(() =>
            {
                IsNew = true;

                Sale = new SaleWrapper();
                Sale.PropertyChanged += Model_PropertyChanged;
                ((DelegateCommand)SaveCommand).RaiseCanExecuteChanged();

                Sale.Date = DateTime.Today;
                Sale.ClientId = 0;
                Sale.ResponsibleId = 0;
                Sale.Discount = 0;
                Sale.Tax = 0;
                Sale.Total = 0;
                Sale.DeliveryFee = 0;
                Sale.HasInvoice = false; // This already sets the invoiceId to 0
                Sale.BranchId = SessionInfo.Branch.Id;
            });

            await base.LoadDetailAsync().ConfigureAwait(false);
        }

        private async Task LoadBranchesAsync()
        {
            var branches = await _saleRepository.GetAllBranchesAsync();

            foreach (var branch in branches)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    Branches.Add(branch);
                });
            }
        }

        private async Task LoadClientsAsync()
        {
            var clients = await _saleRepository.GetAllClientsAsync();

            foreach (var client in clients)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    Clients.Add(client);
                });
            }
        }

        private async Task LoadResponsiblesAsync()
        {
            var responsibles = await _saleRepository.GetAllSalesResponsiblesAsync();

            foreach (var responsible in responsibles)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    Responsibles.Add(responsible);
                });
            }
        }

        private async Task LoadWorkUnitAsync()
        {
            var workUnits = await _saleRepository.GetAllWorkUnitsAsync();

            foreach (var workUnit in workUnits)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    ExistingWorkUnits.Add(workUnit);
                });
            }
        }
    }
}
