﻿namespace SistemaMirno.UI.ViewModel.Detail.Interfaces
{
    public interface IBranchDetailViewModel : IDetailViewModelBase
    {
    }
}