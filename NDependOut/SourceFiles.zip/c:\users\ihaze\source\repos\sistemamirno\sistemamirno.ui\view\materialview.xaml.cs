﻿using System.Windows.Controls;

namespace SistemaMirno.UI.View
{
    /// <summary>
    /// Interaction logic for MaterialView.xaml
    /// </summary>
    public partial class MaterialView : UserControl
    {
        public MaterialView()
        {
            InitializeComponent();
        }
    }
}