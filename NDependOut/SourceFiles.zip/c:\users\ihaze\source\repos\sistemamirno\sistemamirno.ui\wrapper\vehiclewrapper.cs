﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaMirno.Model;

namespace SistemaMirno.UI.Wrapper
{
    public class VehicleWrapper : ModelWrapper<Vehicle>
    { public VehicleWrapper()
            : base(new Vehicle())
        {
        }

        public VehicleWrapper(Vehicle model)
            : base(model)
        {
        }

        public int Id => GetValue<int>();

        public string Model
        {
            get => GetValue<string>();
            set => SetValue(value);
        }

        public int Year
        {
            get => GetValue<int>();
            set => SetValue(value);
        }

        public int Odometer
        {
            get => GetValue<int>();
            set => SetValue(value);
        }

        /// <inheritdoc/>
        protected override IEnumerable<string> ValidateProperty(string propertyName)
        {
            switch (propertyName)
            {
                case nameof(Name):
                    if (Name.Length < 4)
                    {
                        yield return "El nombre es muy corto.";
                    }

                    break;
            }

            foreach (var error in base.ValidateProperty(propertyName))
            {
                if (error != null)
                {
                    yield return error;
                }
            }
        }
    }
}
