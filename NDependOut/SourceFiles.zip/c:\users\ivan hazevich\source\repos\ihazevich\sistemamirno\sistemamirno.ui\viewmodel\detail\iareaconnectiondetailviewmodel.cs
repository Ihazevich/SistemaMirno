﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IAreaConnectionDetailViewModel : IDetailViewModelBase
    {
        void SetWorkAreaId(int id);
    }
}