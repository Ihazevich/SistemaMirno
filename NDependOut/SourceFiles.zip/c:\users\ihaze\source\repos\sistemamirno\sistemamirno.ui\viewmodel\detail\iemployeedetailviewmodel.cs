﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IEmployeeDetailViewModel : IDetailViewModelBase
    {
    }
}