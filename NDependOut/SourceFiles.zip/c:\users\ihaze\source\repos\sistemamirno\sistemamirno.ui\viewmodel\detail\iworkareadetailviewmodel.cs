﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IWorkAreaDetailViewModel : IDetailViewModelBase
    {
    }
}