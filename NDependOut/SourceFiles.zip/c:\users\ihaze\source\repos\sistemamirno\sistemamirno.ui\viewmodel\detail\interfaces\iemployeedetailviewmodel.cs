﻿namespace SistemaMirno.UI.ViewModel.Detail.Interfaces
{
    public interface IEmployeeDetailViewModel : IDetailViewModelBase
    {
    }
}