﻿using SistemaMirno.UI.ViewModel.Detail.Interfaces;

namespace SistemaMirno.UI.ViewModel.Detail.Interfaces
{
    public interface IRequisitionDetailViewModel : IDetailViewModelBase
    {
    }
}