﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IProductCategoryDetailViewModel : IDetailViewModelBase
    {
    }
}