﻿// <copyright file="IWorkAreaDetailViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

namespace SistemaMirno.UI.ViewModel.Detail.Interfaces
{
    public interface IWorkAreaDetailViewModel : IDetailViewModelBase
    {
    }
}