﻿using System.Windows.Controls;

namespace SistemaMirno.UI.View.General
{
    /// <summary>
    /// Interaction logic for ProductCategoryView.xaml
    /// </summary>
    public partial class ProductCategoryView : UserControl
    {
        public ProductCategoryView()
        {
            InitializeComponent();
        }
    }
}