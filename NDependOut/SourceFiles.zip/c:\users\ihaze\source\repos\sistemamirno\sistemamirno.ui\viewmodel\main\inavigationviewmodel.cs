﻿// <copyright file="INavigationViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

namespace SistemaMirno.UI.ViewModel.Main
{
    public interface INavigationViewModel : IViewModelBase
    {
    }
}