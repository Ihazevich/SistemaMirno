﻿using System.Threading.Tasks;

namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IUserDetailViewModel : IDetailViewModelBase
    {
    }
}