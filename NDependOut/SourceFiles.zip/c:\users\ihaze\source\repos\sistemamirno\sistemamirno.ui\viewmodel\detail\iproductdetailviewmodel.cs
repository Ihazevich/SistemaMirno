﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IProductDetailViewModel : IDetailViewModelBase
    {
    }
}