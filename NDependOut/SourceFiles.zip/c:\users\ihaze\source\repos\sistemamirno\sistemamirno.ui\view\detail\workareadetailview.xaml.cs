﻿using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Input;

namespace SistemaMirno.UI.View.Detail
{
    /// <summary>
    /// Interaction logic for ProductionAreaDetailView.xaml
    /// </summary>
    public partial class WorkAreaDetailView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WorkAreaDetailView"/> class.
        /// </summary>
        public WorkAreaDetailView()
        {
            InitializeComponent();
        }
    }
}