﻿using System.Windows.Controls;

namespace SistemaMirno.UI.View.Detail
{
    /// <summary>
    /// Interaction logic for ProductDetailView.xaml
    /// </summary>
    public partial class ProductDetailView : UserControl
    {
        public ProductDetailView()
        {
            InitializeComponent();
        }
    }
}