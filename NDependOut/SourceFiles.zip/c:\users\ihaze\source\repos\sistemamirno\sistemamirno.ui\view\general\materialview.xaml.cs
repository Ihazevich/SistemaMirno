﻿using System.Windows.Controls;

namespace SistemaMirno.UI.View.General
{
    /// <summary>
    /// Interaction logic for MaterialView.xaml
    /// </summary>
    public partial class MaterialView : UserControl
    {
        public MaterialView()
        {
            InitializeComponent();
        }
    }
}