﻿namespace SistemaMirno.UI.Wrapper
{
    public interface IModelWrapper
    {
        bool HasErrors { get; }
    }
}