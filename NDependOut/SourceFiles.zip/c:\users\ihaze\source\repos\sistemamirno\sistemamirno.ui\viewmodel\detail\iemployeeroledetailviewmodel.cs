﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IEmployeeRoleDetailViewModel : IDetailViewModelBase
    {
    }
}