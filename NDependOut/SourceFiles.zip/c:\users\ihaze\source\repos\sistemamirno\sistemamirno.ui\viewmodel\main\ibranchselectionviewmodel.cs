﻿namespace SistemaMirno.UI.ViewModel.Main
{
    public interface IBranchSelectionViewModel : IViewModelBase
    {
    }
}