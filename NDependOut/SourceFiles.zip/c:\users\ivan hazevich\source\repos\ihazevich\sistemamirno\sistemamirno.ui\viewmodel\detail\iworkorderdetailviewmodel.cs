﻿namespace SistemaMirno.UI.ViewModel.Detail
{
    public interface IWorkOrderDetailViewModel : IDetailViewModelBase
    {
    }
}