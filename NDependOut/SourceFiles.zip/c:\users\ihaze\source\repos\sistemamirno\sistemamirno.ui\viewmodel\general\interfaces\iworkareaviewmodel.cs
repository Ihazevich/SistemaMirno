﻿// <copyright file="IWorkAreaViewModel.cs" company="HazeLabs">
// Copyright (c) HazeLabs. All rights reserved.
// </copyright>

namespace SistemaMirno.UI.ViewModel.General.Interfaces
{
    public interface IWorkAreaViewModel : IViewModelBase
    {
    }
}