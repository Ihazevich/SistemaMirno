﻿namespace SistemaMirno.UI.ViewModel.General.Interfaces
{
    public interface IWorkAreaViewModel : IViewModelBase
    {
    }
}